package org.system;

public class Computer {
	
	public void computerModel() {
		System.out.println("The computer model is DELL.");

	}

	public static void main(String[] args) {
		Computer comp= new Computer();
		comp.computerModel();

	}

}
